test_that("output format meql", {

  expect_equal(2 * 2, 4)

  load(file = "testdata.Rda")

  data_meq <- meql(data)
  expect_true(ncol(data_meq) == 18)

  #expect_error()

})

test_that("coordinates must be present", {

  x_coordinate <-
  export_error()

})
