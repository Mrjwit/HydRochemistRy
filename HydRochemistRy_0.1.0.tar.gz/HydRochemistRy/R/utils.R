#  Helper functions for HydRochemistRy package
#

valid_parameters <- function() {
  # returns valid parameters
  return(c("Cl", "HCO3", "SO4", "NO3", "PO4", "Na", "Ca", "Mg", "K", "Fe", "NH4"))

}

check_columns <- function(d) {
  # test if mandatory columns are present

  col_numeric <- c("year", "value", "sd", "detection_limit", "xcoord", "ycoord")
  col <- c("putcode", "samplecode", "parameter", "limit_symbol", "units", "method", "notes",
           "watercode", "sampletype", "subtype", col_numeric)

  if(length(setdiff(col, names(d)) > 0)) {
    stop("Columns are missing or are not recognized: Check column names.")
  }

  for(i in col_numeric) {
    if(!is.numeric(d[[i]])) {
      stop(paste("Column", i, "is not numeric"))
    }

  }

}

